import React, { Component } from 'react';

class BlogPost extends Component {
  render() {
    return (
      <div>
        Post
      </div>
    );
  }
}

export default BlogPost;
