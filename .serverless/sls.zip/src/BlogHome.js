import React, { Component } from 'react';

class BlogHome extends Component {
  render() {
    return (
      <div>
        Home
      </div>
    );
  }
}

export default BlogHome;
