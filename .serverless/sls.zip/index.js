'use strict';

exports.test1 = (request, response) => {
  response.status(200).send('Colton was here')
}
